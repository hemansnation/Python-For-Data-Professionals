class InferentialStatistics:

    def Hypothesis(self):
        return "Hypothesis from Inferential Statistics"
    
